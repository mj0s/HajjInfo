import { sendEmail } from "../utils/send-email";
import fs from "fs";
import path from "path";

export async function POST(request) {
  try {
    const { email } = await request.json();

    if (!email) {
      return Response.json({ error: "Email is required" }, { status: 400 });
    }

    // Read the hajj.txt file
    const filePath = path.join(process.cwd(), "public", "hajj.txt");
    const fileContent = fs.readFileSync(filePath, "utf-8");

    // Convert to base64
    const base64Content = Buffer.from(fileContent, "utf-8").toString("base64");

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: [email],
        subject: "خارطة أعمال الحج - جمعية هاد للدعوة والإرشاد بعنيزة",
        html: `
          <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; background: #f0fdf4; border-radius: 12px;">
            <h1 style="color: #065f46; text-align: center;">خارطة أعمال الحج</h1>
            <p style="color: #1e293b; font-size: 16px; line-height: 1.8; text-align: center;">
              السلام عليكم ورحمة الله وبركاته،<br/>
              مرفق ملف خارطة أعمال الحج من جمعية هاد للدعوة والإرشاد بعنيزة.
            </p>
            <p style="color: #64748b; font-size: 14px; text-align: center; margin-top: 16px;">
              ⚠️ بعد تنزيل الملف، قم بإعادة تسميته من <strong>hajj.txt</strong> إلى <strong>hajj.html</strong> ثم افتحه في المتصفح.
            </p>
            <div style="text-align: center; margin-top: 24px; color: #065f46; font-size: 14px;">
              جمعية هاد للدعوة والإرشاد بعنيزة
            </div>
          </div>
        `,
        attachments: [
          {
            filename: "hajj.html",
            content: base64Content,
          },
        ],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Failed to send email");
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error("Email send error:", error);
    return Response.json(
      { error: error.message || "Failed to send email" },
      { status: 500 },
    );
  }
}
