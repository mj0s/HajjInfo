import React, { useState, useEffect, useCallback } from "react";
import { hajjStages } from "../data/hajjStages";
import {
  CheckCircle2,
  Circle,
  Home,
  Plane,
  User,
  RefreshCw,
  Tent,
  Sun,
  Moon,
  Scissors,
  Layers,
  LogOut,
  ChevronLeft,
  Info,
  Calendar,
  Check,
  Star,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const icons = [
  Home,
  Plane,
  User,
  RefreshCw,
  Tent,
  Sun,
  Moon,
  Scissors,
  Layers,
  LogOut,
];

export default function HajjEngagementPlatform() {
  const [completedStages, setCompletedStages] = useState([]);
  const [selectedStage, setSelectedStage] = useState(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    const saved = localStorage.getItem("hajj_progress");
    if (saved) {
      setCompletedStages(JSON.parse(saved));
    }
  }, []);

  const toggleStage = useCallback((id) => {
    setCompletedStages((prev) => {
      const next = prev.includes(id)
        ? prev.filter((item) => item !== id)
        : [...prev, id];
      localStorage.setItem("hajj_progress", JSON.stringify(next));
      return next;
    });
  }, []);

  const progress = (completedStages.length / hajjStages.length) * 100;

  if (!isMounted) return null;

  return (
    <div
      className="min-h-screen bg-[#f0fdf4] text-[#1e293b] font-sans pb-20"
      dir="rtl"
    >
      {/* Header */}
      <header className="bg-gradient-to-b from-[#064e3b] to-[#065f46] text-white sticky top-0 z-40 shadow-lg">
        <div className="max-w-2xl mx-auto px-4 pt-8 pb-6 flex flex-col items-center gap-3">
          {/* Decorative Stars */}
          <div className="flex items-center gap-3 text-[#a7f3d0] text-xl mb-1">
            <span>✦</span>
            <span>✦</span>
            <span>✦</span>
            <span>✦</span>
            <span>✦</span>
          </div>

          <h1 className="text-3xl md:text-4xl font-extrabold text-white text-center leading-snug">
            خَارطَةُ أَعْمَالِ الحَجّ
          </h1>
          <p className="text-[#a7f3d0] text-base text-center">
            اضغط على أي مرحلة لمعرفة الأعمال والأدعية
          </p>

          {/* Progress Counter */}
          <div className="mt-1 text-[#6ee7b7] text-lg font-bold">
            {completedStages.length}/{hajjStages.length} مرحلة
          </div>

          {/* Progress Bar */}
          <div className="w-full max-w-sm mt-1 h-2.5 bg-[#065f46]/60 rounded-full overflow-hidden border border-[#a7f3d0]/30">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className="h-full bg-[#6ee7b7] rounded-full"
            />
          </div>

          {/* Logo */}
          <div className="mt-3 w-20 h-20 rounded-full overflow-hidden bg-white shadow-xl flex items-center justify-center">
            <img
              src="https://raw.createusercontent.com/dce4f252-78f2-4384-a4ac-d76f289e8352/"
              alt="شعار جمعية هاد"
              className="w-full h-full object-contain"
              onError={(e) => {
                e.target.style.display = "none";
                e.target.parentElement.innerHTML =
                  '<span class="text-2xl font-bold text-[#065f46]">هاد</span>';
              }}
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 py-8">
        <div className="flex flex-col gap-4">
          {hajjStages.map((stage, index) => {
            const Icon = icons[index];
            const isCompleted = completedStages.includes(stage.id);

            return (
              <motion.div
                key={stage.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedStage(stage)}
                className={`relative p-5 rounded-2xl border-2 cursor-pointer transition-all flex items-center gap-4 ${
                  isCompleted
                    ? "bg-white border-[#065f46] shadow-md"
                    : "bg-white border-[#d1fae5] hover:border-[#6ee7b7] shadow-sm"
                }`}
              >
                {/* Stage Number */}
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${isCompleted ? "bg-[#065f46] text-white" : "bg-[#d1fae5] text-[#065f46]"}`}
                >
                  {index + 1}
                </div>

                {/* Icon */}
                <div
                  className={`p-3 rounded-xl shrink-0 ${isCompleted ? "bg-[#065f46] text-white" : "bg-[#f0fdf4] text-[#065f46]"}`}
                >
                  <Icon size={22} />
                </div>

                {/* Text */}
                <div className="flex-1 min-w-0">
                  <h3
                    className={`text-lg font-bold ${isCompleted ? "text-[#065f46]" : "text-[#1e293b]"}`}
                  >
                    {stage.title}
                  </h3>
                  <p className="text-[#64748b] text-sm mt-0.5 line-clamp-1">
                    {stage.description}
                  </p>
                </div>

                {/* Check Icon */}
                <div className="shrink-0">
                  {isCompleted ? (
                    <CheckCircle2 className="text-[#065f46]" size={24} />
                  ) : (
                    <Circle className="text-[#cbd5e1]" size={24} />
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Hint */}
        <div className="mt-8 text-center text-[#64748b] text-sm py-4">
          ☝️ اضغط على أي مرحلة للاطلاع على تفاصيلها
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto py-8 text-center text-[#94a3b8] text-sm">
        <p className="font-semibold text-[#065f46] text-base mb-4">
          جمعية هاد للدعوة والإرشاد بعنيزة
        </p>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          {/* X (Twitter) */}
          <a
            href="https://x.com/JalyatUnaizah"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded-full text-sm font-bold hover:bg-[#333] transition-colors"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.747l7.73-8.835L1.254 2.25H8.08l4.253 5.622L18.244 2.25zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z" />
            </svg>
            @JalyatUnaizah
          </a>

          {/* WhatsApp */}
          <a
            href="https://wa.me/966553632020"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-[#25D366] text-white px-4 py-2 rounded-full text-sm font-bold hover:bg-[#1ebe5d] transition-colors"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            0553632020
          </a>
        </div>
      </footer>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedStage && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedStage(null)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[50]"
            />
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed bottom-0 inset-x-0 bg-white rounded-t-[32px] z-[60] max-h-[90vh] overflow-y-auto shadow-2xl"
            >
              <div className="max-w-2xl mx-auto p-8">
                <div className="w-16 h-1.5 bg-[#e2e8f0] rounded-full mx-auto mb-8" />

                <div className="flex flex-col gap-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-4 bg-[#065f46] rounded-2xl text-white">
                        {React.createElement(
                          icons[hajjStages.indexOf(selectedStage)],
                          { size: 32 },
                        )}
                      </div>
                      <div>
                        <h2 className="text-3xl font-extrabold text-[#065f46]">
                          {selectedStage.title}
                        </h2>
                        <p className="text-[#64748b] mt-1">
                          {selectedStage.description}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedStage(null)}
                      className="p-2 hover:bg-[#f1f5f9] rounded-full transition-colors"
                    >
                      <ChevronLeft size={32} />
                    </button>
                  </div>

                  <div className="space-y-8 mt-4">
                    {/* Acts Section */}
                    <div>
                      <h4 className="flex items-center gap-2 text-xl font-bold text-[#1e293b] mb-4 border-r-4 border-[#065f46] pr-3">
                        <Calendar size={24} className="text-[#065f46]" />
                        الأعمال المطلوبة
                      </h4>
                      <ul className="space-y-3">
                        {selectedStage.acts.map((act, i) => (
                          <li
                            key={i}
                            className="flex items-start gap-3 p-4 bg-[#f8fafc] rounded-xl border border-[#f1f5f9]"
                          >
                            <div className="mt-1">
                              <CheckCircle2
                                size={18}
                                className="text-[#065f46]"
                              />
                            </div>
                            <span className="text-[#334155] leading-relaxed">
                              {act}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Duas Section */}
                    <div>
                      <h4 className="flex items-center gap-2 text-xl font-bold text-[#1e293b] mb-4 border-r-4 border-[#065f46] pr-3">
                        <Info size={24} className="text-[#065f46]" />
                        الأدعية والذكر
                      </h4>
                      <div className="p-6 bg-[#065f46]/5 rounded-2xl border-2 border-[#065f46]/10 italic text-[#065f46] text-center text-lg leading-loose font-medium">
                        {selectedStage.duas.map((dua, i) => (
                          <p key={i}>"{dua}"</p>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      toggleStage(selectedStage.id);
                      setSelectedStage(null);
                    }}
                    className={`mt-8 w-full py-5 rounded-2xl font-bold text-xl flex items-center justify-center gap-3 transition-all ${
                      completedStages.includes(selectedStage.id)
                        ? "bg-[#ef4444] text-white shadow-lg shadow-red-200"
                        : "bg-[#065f46] text-white shadow-lg shadow-emerald-200 hover:bg-[#047857]"
                    }`}
                  >
                    {completedStages.includes(selectedStage.id) ? (
                      <>إلغاء الإكمال</>
                    ) : (
                      <>
                        <Check size={24} />
                        تحديد كمكتمل
                      </>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Noto+Sans+Arabic:wght@100..900&display=swap');
        body { font-family: 'Noto Sans Arabic', sans-serif; }
        h1, h2, h3, h4 { font-family: 'Amiri', serif; }
      `}</style>
    </div>
  );
}
